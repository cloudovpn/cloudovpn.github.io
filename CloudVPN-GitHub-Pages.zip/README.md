# CloudVPN Official Website

Static GitHub Pages site for CloudVPN Android app (`com.cloudvpn.openvpn`).

## Pages
- `index.html`: Thai homepage
- `en.html`: English homepage
- `privacy.html`: App Privacy Policy (review factual disclosures before publishing)
- `account-deletion.html`: Account/data deletion request information

## Publish to GitHub Pages
1. Sign in to the GitHub account or organization named `cloudvpn` (the exact username matters). You must own that username. A repository named `cloudvpn.github.io` under a different account will NOT publish at that domain.
2. Create or open a public repository named `cloudvpn.github.io`.
3. Upload **the contents of this folder** to the repository root, including `index.html`, `en.html`, `favicon.svg`, `assets/` and `.nojekyll`.
4. In Settings → Pages, choose "Deploy from a branch", select `main` and `/(root)`, then Save.
5. Open https://cloudvpn.github.io/ after publishing.

**Google Play listing:** https://play.google.com/store/apps/details?id=com.cloudvpn.openvpn (may show 404 until the app is released).

**Privacy Policy URL for Play Console:** https://cloudvpn.github.io/privacy.html

**Account deletion URL:** https://cloudvpn.github.io/account-deletion.html

**Important:** The privacy policy is a draft based on the project's described features and may not exactly match app SDKs and server retention. Verify SDKs, consent flows, collection, sharing, actual retention and deletion procedures, and Play Console Data safety/VpnService disclosures before publication. The deletion page describes an email-based request flow and should only be published if you can actually process requests accordingly.

To change the email, update all HTML pages. No external JavaScript libraries, tracking code, or build step are required.
